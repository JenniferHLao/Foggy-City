# What percent of the city is foggy
# jennifer lao
# 22nd of march

#import the module for dealing w/ graphics
#import the modulde for time 

import time
t0 = time.time()
from PIL import Image

#Import the image
Fog = Image.open("Foggy_city.jpg")
Foggy_city = Fog.load()
#set the peramiters for the pixels
width = Fog.width
height = Fog.height

#initialise counters for Fog
Fog_pix = 0 

for i in range(width):
  for j in range(height):
    #for all the pixels that are white, or (255,255,255)add a +1 to the fog counter
    r = Foggy_city[i,j][0]
    g = Foggy_city[i,j][1]
    b = Foggy_city[i,j][2]
    
    if r>150 and g > 150 and b> 150:
      Fog_pix += 1
      
#finish time
t1 = time.time()
res = width*height
timing = float(t1-t0)
Final_Fog = str((Fog_pix/res)*100)
Final_statement = "It took me {:.3f}s to calculate the amount of fog in that photo".format(timing)
Final_1= "But it was worth the weight! Turns out that " +Final_Fog+ "% of the photo is actually covered in fog!"
print(Final_statement)
print(Final_1)

